package com.test5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Test5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
